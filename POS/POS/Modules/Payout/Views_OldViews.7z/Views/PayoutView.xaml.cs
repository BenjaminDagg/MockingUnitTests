﻿using System.ComponentModel;
using System.Windows.Controls;

namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for PayoutView.xaml
    /// </summary>
    public partial class PayoutView : UserControl
    {
        public PayoutView()
        {
            InitializeComponent();
        }

        

      
    }
}
