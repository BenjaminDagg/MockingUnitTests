﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Framework.WPF.UI.Controls;

namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for StartingBalanceDialog.xaml
    /// </summary>
    public partial class StartingBalancePromptView : CustomWindowControl
    {
        public StartingBalancePromptView()
        {
            InitializeComponent();
        }
    }
}
