﻿namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for AddCashPromptView.xaml
    /// </summary>
    public partial class VoucherDetailPromptView
    {
        public VoucherDetailPromptView()
        {
            InitializeComponent();
        }
    }
}
