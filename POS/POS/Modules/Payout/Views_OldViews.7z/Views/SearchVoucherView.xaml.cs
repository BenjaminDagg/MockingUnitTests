﻿using System.Windows.Controls;

namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for SearchVoucherView.xaml
    /// </summary>
    public partial class SearchVoucherView
    {
        public SearchVoucherView()
        {
            InitializeComponent();
        }

        //private void ValidationNumberTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
        //{
        //    var t = (TextBox)sender;
        //    t.Focus();
        //    t.CaretIndex = t.Text.Length;
        //}
    }
}
