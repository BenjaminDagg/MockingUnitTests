﻿using Framework.WPF.UI.Controls;

namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for AddCashPromptView.xaml
    /// </summary>
    public partial class AddRemoveCashPromptView : CustomWindowControl
    {
        public AddRemoveCashPromptView()
        {
            InitializeComponent();
        }
    }
}
