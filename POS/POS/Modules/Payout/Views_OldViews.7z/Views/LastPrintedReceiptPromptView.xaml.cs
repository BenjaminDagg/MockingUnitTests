﻿using Framework.WPF.UI.Controls;

namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for AddCashPromptView.xaml
    /// </summary>
    public partial class LastPrintedReceiptPromptView : CustomWindowControl
    {
        public LastPrintedReceiptPromptView()
        {
            InitializeComponent();
        }
    }
}
