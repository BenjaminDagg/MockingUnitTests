﻿using System.Windows;

namespace POS.Modules.Payout.Views
{
    /// <summary>
    /// Interaction logic for ReportView.xaml
    /// </summary>
    public partial class VoucherReportView : Window
    {
        public VoucherReportView()
        {
            InitializeComponent();
          
        }
    }
}
